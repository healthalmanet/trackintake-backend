# ml_model/src/generator.py

# ================================
# 🔹 Required Library Imports
# ================================
import torch
import pandas as pd
import json
import os
import random
from collections import defaultdict
import numpy as np

# ================================
# 🔹 Import Custom Modules
# ================================
from .model import Encoder, Decoder, Seq2Seq
from .rule_engine import get_allowed_foods

# ================================
# 🔹 Import Django ORM Models
# ================================
try:
    from user.models import User
    from userProfile.models import UserProfile, LabReport
except ImportError:
    print("⚠️ WARNING: Django models not found. Using mock objects for demonstration.")
    from unittest.mock import Mock, MagicMock
    User = Mock()
    User.objects = MagicMock()
    UserProfile = Mock()
    UserProfile.objects = MagicMock()
    LabReport = Mock()
    LabReport.objects = MagicMock()

# ================================
# 🔸 Initialization Logs
# ================================
print("AI DIET PLANNER (OPTIMIZER V2 with DETAILED TEMPLATES): Initializing...")

# ================================
# 🔹 Configuration
# ================================
SRC_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(SRC_DIR)

V2_MODEL_PATH = os.path.join(BASE_DIR, 'saved_models', 'diet_model_v2.pth')
V1_MODEL_PATH = os.path.join(BASE_DIR, 'saved_models', f'diet_model_v1_epoch_79.pth')

if os.path.exists(V2_MODEL_PATH):
    MODEL_PATH = V2_MODEL_PATH
    MODEL_VERSION = 'v2'
    print(f"✅ Using retrained V2 model: {MODEL_PATH}")
else:
    MODEL_PATH = V1_MODEL_PATH
    MODEL_VERSION = 'v1'
    print(f"⚠️ V2 model not found. Falling back to V1 model: {MODEL_PATH}")

VOCAB_FILE = os.path.join(BASE_DIR, 'saved_models', 'food_vocab.json')
FOOD_DATA_FILE = os.path.join(BASE_DIR, 'data', 'food_items.xlsx')
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

PLAN_DAYS = 15
MEAL_NAMES = ['Early-Morning', 'Breakfast', 'Mid-Morning Snack', 'Lunch', 'Afternoon Snack', 'Dinner', 'Bedtime']
MEALS_PER_DAY = len(MEAL_NAMES)
TOP_K = 50

# ================================
# 🔸 Load Vocabulary, Model, and Food Data
# ================================
try:
    with open(VOCAB_FILE, 'r') as f:
        food_vocab = json.load(f)
    inv_food_vocab = {v: k for k, v in food_vocab.items()}
    OUTPUT_DIM = len(food_vocab)
except FileNotFoundError:
    raise RuntimeError(f"FATAL: Missing vocabulary file: {VOCAB_FILE}. Cannot proceed.")

NUMERICAL_COLS = [
    'Age', 'Weight (kg)', 'Height (cm)', 'BMI (auto-calculated)', 'Waist Circumference (cm)', 'Fasting Blood Sugar (mg/dL)',
    'HbA1c (%)', 'Postprandial Sugar (mg/dL)', 'LDL (mg/dL)', 'HDL (mg/dL)', 'Triglycerides (mg/dL)', 'CRP (mg/L)',
    'ESR (mm/hr)', 'Uric Acid (mg/dL)', 'Creatinine (mg/dL)', 'Urea (mg/dL)', 'ALT (U/L)', 'AST (U/L)', 'Vitamin D3 (ng/mL)',
    'Vitamin B12 (pg/mL)', 'TSH (uIU/mL)'
]
INPUT_DIM = len(NUMERICAL_COLS)

try:
    encoder = Encoder(INPUT_DIM, 256, 512)
    decoder = Decoder(OUTPUT_DIM, 256, 512)
    model = Seq2Seq(encoder, decoder, DEVICE).to(DEVICE)
    checkpoint = torch.load(MODEL_PATH, map_location=DEVICE)
    state_dict = checkpoint.get('model_state_dict', checkpoint)
    model.load_state_dict(state_dict)
    model.eval()
    print(f"✅ Model '{MODEL_VERSION}' loaded successfully.")
except Exception as e:
    raise RuntimeError(f"FATAL: Error loading model from {MODEL_PATH}: {e}")

try:
    food_df = pd.read_excel(FOOD_DATA_FILE)
    food_df.columns = [col.strip().replace('/g', '').replace('/mg', '').replace('(kcal)', '') for col in food_df.columns]
    food_df['Food_Item'] = food_df['Food_Item'].str.strip()
    numeric_cols = ['Household_Weight_g', 'Min_Units', 'Max_Units', 'Calories', 'Protein', 'Carbs', 'Fats', 'Sugar', 'Fiber',
                    'Saturated_Fat', 'Trans_Fat', 'Sodium', 'Potassium', 'Omega_3']
    for col in numeric_cols:
        if col in food_df.columns:
            food_df[col] = pd.to_numeric(food_df[col], errors='coerce').fillna(0)
    food_df.set_index('Food_Item', inplace=True)
    print(f"✅ Loaded and processed {len(food_df)} unique food items.")
except FileNotFoundError:
    raise RuntimeError(f"FATAL: Food data file not found at {FOOD_DATA_FILE}.")
except Exception as e:
    raise RuntimeError(f"FATAL: Failed to load food file {FOOD_DATA_FILE}: {e}")

# =============================================================================
# ⭐️ Nutritional Target Calculation (No Changes Here)
# =============================================================================
def calculate_daily_needs(user_report):
    age = user_report.get('Age', 30)
    weight = user_report.get('Weight (kg)', 70)
    height = user_report.get('Height (cm)', 170)
    gender = user_report.get('Gender', 'Male').lower()
    activity = user_report.get('Activity Level', 'Sedentary').lower()
    if gender == 'male':
        bmr = 10 * weight + 6.25 * height - 5 * age + 5
    else:
        bmr = 10 * weight + 6.25 * height - 5 * age - 161
    multipliers = {'sedentary': 1.2, 'lightly active': 1.375, 'moderately active': 1.55, 'very active': 1.725}
    multiplier = multipliers.get(activity.replace(" ", ""), 1.2)
    target_calories = bmr * multiplier
    return {
        'calories': target_calories,
        'protein': (target_calories * 0.30) / 4,
        'carbs': (target_calories * 0.40) / 4,
        'fats': (target_calories * 0.30) / 9
    }

# =============================================================================
# ⭐️⭐️⭐️ REWRITTEN: Meal Construction with DETAILED Templates ⭐️⭐️⭐️
# =============================================================================
def construct_meal(meal_name, ai_suggestion, food_pool_df, is_veg):
    """Builds a meal based on DETAILED templates and returns a list of food items."""
    meal_composition = []
    
    def select_food(category, fallback_suggestion=None):
        """Helper to safely select a food from a category."""
        category_foods = food_pool_df[food_pool_df['Category'].str.contains(category, na=False, case=False)]
        if not category_foods.empty:
            return category_foods.sample(1).index[0]
        if fallback_suggestion and fallback_suggestion in food_pool_df.index:
            return fallback_suggestion
        if not food_pool_df.empty:
            # As a last resort, pick from the entire pool, but log it.
            print(f"WARNING: No food found for category '{category}'. Picking random food as fallback.")
            return food_pool_df.sample(1).index[0]
        return None

    # --- Template Logic for Each Meal Slot ---

    if meal_name == 'Early-Morning':
        meal_composition.append(select_food('Morning drink'))
        meal_composition.append(select_food('Dry fruits and nuts'))

    elif meal_name == 'Breakfast':
        meal_composition.append(select_food('Breakfast dishes', ai_suggestion))
        meal_composition.append(select_food('Fruits'))

    elif meal_name == 'Mid-Morning Snack':
        if np.random.rand() < 0.5: # 50% chance for Smoothie vs Fruit
             meal_composition.append(select_food('Smoothie'))
        else:
             meal_composition.append(select_food('Fruits'))
        meal_composition.append(select_food('Dry fruits and nuts'))

    elif meal_name == 'Lunch':
        is_one_pot = ai_suggestion and ai_suggestion in food_pool_df.index and food_pool_df.loc[ai_suggestion, 'Is_One_Pot'] == 'Y'
        
        if is_one_pot: # One-Pot Lunch Template
            meal_composition.append(ai_suggestion)
            meal_composition.append(select_food('Siders'))
        else: # Thali Lunch Template
            if is_veg:
                meal_composition.append(select_food('Indian breads'))
                meal_composition.append(select_food('Dal', ai_suggestion))
                meal_composition.append(select_food('Sabzi'))
                meal_composition.append(select_food('Rice dishes'))
                meal_composition.append(select_food('Siders'))
                meal_composition.append(select_food('Dairy'))
            else: # Non-Veg Thali
                meal_composition.append(select_food('Indian breads'))
                meal_composition.append(select_food('Non-veg curry', ai_suggestion))
                meal_composition.append(select_food('Rice dishes'))
                meal_composition.append(select_food('Siders'))
                if np.random.rand() < 0.7: # Sabzi is optional (70% chance)
                    meal_composition.append(select_food('Sabzi'))
    
    elif meal_name == 'Afternoon Snack':
        meal_composition.append(select_food('Snacks', ai_suggestion))

    elif meal_name == 'Dinner':
        is_one_pot = ai_suggestion and ai_suggestion in food_pool_df.index and food_pool_df.loc[ai_suggestion, 'Is_One_Pot'] == 'Y'

        if is_one_pot: # One-Pot Dinner Template
            meal_composition.append(ai_suggestion)
            meal_composition.append(select_food('Siders'))
        else: # Thali Dinner Template (lighter than lunch)
            if is_veg:
                meal_composition.append(select_food('Indian breads'))
                meal_composition.append(select_food('Sabzi', ai_suggestion))
                meal_composition.append(select_food('Siders'))
            else: # Non-Veg Thali
                meal_composition.append(select_food('Indian breads'))
                meal_composition.append(select_food('Non-veg curry', ai_suggestion))
                meal_composition.append(select_food('Siders'))
    
    elif meal_name == 'Bedtime':
        meal_composition.append(select_food('Night time drinks', ai_suggestion))

    return [food for food in meal_composition if food] # Filter out any None values

# =============================================================================
# ⭐️ Portion Optimization Logic (No Changes Here)
# =============================================================================
def optimize_portions(meal_foods, remaining_targets):
    meal_details = []
    if not meal_foods: return [], remaining_targets
    
    # Simple calorie distribution - can be made smarter later
    # Example: give more calories to main dishes
    num_items = len(meal_foods)
    calories_per_item = remaining_targets['calories'] / num_items if num_items > 0 else 0
    
    for food_name in meal_foods:
        if food_name not in food_df.index: continue
        food_info = food_df.loc[food_name]
        
        base_calories = food_info['Calories']
        if base_calories > 0:
            num_units = round(calories_per_item / base_calories)
        else:
            num_units = food_info.get('Min_Units', 1)
        
        num_units = max(food_info.get('Min_Units', 1), min(num_units, food_info.get('Max_Units', 5)))
        num_units = int(num_units)

        final_nutrition = {
            "food_name": food_name,
            "quantity": num_units,
            "unit": food_info.get('Display_Unit', 'unit'),
            "calories": food_info['Calories'] * num_units,
            "protein": food_info['Protein'] * num_units,
            "carbs": food_info['Carbs'] * num_units,
            "fats": food_info['Fats'] * num_units,
        }
        meal_details.append(final_nutrition)
        
        for key in ['calories', 'protein', 'carbs', 'fats']:
            remaining_targets[key] -= final_nutrition[key]

    return meal_details, remaining_targets

# =============================================================================
# ⭐️ Main Plan Generation Function (No Changes Here)
# =============================================================================
def generate_diet_plan(user_id):
    if not all([model, not food_df.empty, food_vocab]):
        return {"error": "AI system not fully initialized."}

    try:
        auth_user = User.objects.get(id=user_id)
        user_profile = UserProfile.objects.get(user=auth_user)
        lab_report = LabReport.objects.filter(user=auth_user).last()
        features = {**user_profile.__dict__, **(lab_report.__dict__ if lab_report else {})}
        
        user_report_series = pd.Series(features)
        input_tensor = torch.tensor(
            user_report_series.reindex(NUMERICAL_COLS).fillna(0).values,
            dtype=torch.float32
        ).unsqueeze(0).to(DEVICE)
        is_veg = user_report_series.get('Dietary Preference', 'Vegetarian').lower() == 'vegetarian'

        daily_targets = calculate_daily_needs(user_report_series)
        allowed_foods_df, suggestion_flags = get_allowed_foods(user_report_series, food_df.reset_index())
        allowed_food_names = set(allowed_foods_df['Food_Item']) & set(food_vocab.keys())

        if len(allowed_food_names) < 20:
            return {"error": f"Not enough food variety ({len(allowed_food_names)} items) available after applying rules."}
        
        allowed_ids = [food_vocab[name] for name in allowed_food_names]

        with torch.no_grad():
            outputs = model.generate(input_tensor, meal_names=MEAL_NAMES * PLAN_DAYS, top_k=TOP_K, allowed_ids=allowed_ids)
        
        ai_suggestions = [inv_food_vocab.get(oid, "Unknown") for oid in outputs]
        
        final_plan = {}
        suggestion_idx = 0
        
        for day in range(1, PLAN_DAYS + 1):
            daily_plan = {}
            # Reset targets for each day
            remaining_targets_for_day = daily_targets.copy()
            daily_totals = defaultdict(float)

            for meal_name in MEAL_NAMES:
                if suggestion_idx >= len(ai_suggestions): break
                ai_suggestion = ai_suggestions[suggestion_idx]
                suggestion_idx += 1
                
                # 1. Construct meal using detailed templates
                meal_foods = construct_meal(meal_name, ai_suggestion, allowed_foods_df, is_veg)
                
                # 2. Optimize portions to meet nutritional goals
                meal_details, remaining_targets_for_day = optimize_portions(meal_foods, remaining_targets_for_day)
                
                daily_plan[meal_name] = meal_details
                for item in meal_details:
                    for key in ['calories', 'protein', 'carbs', 'fats']:
                        daily_totals[key] += item[key]
            
            daily_plan['daily_totals'] = {k: round(v, 2) for k, v in daily_totals.items()}
            daily_plan['daily_targets'] = {k: round(v, 2) for k, v in daily_targets.items()}
            final_plan[f"Day {day}"] = daily_plan

        final_plan["suggestion_flags"] = suggestion_flags
        return final_plan

    except User.DoesNotExist: return {"error": f"User with ID {user_id} not found."}
    except UserProfile.DoesNotExist: return {"error": f"User profile for user ID {user_id} is missing."}
    except Exception as e:
        import traceback
        traceback.print_exc()
        return {"error": f"An unexpected error occurred: {e}"}