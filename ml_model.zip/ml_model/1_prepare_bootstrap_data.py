# ml_model/1_prepare_bootstrap_data.py

# 🔹 Import required libraries
import pandas as pd
import numpy as np
import json
from src.rule_engine import get_allowed_foods
from tqdm import tqdm
import os

# 🔸 Configuration constants
NUM_PLANS_PER_USER = 50
PLAN_DAYS = 15
MEALS_PER_DAY = 7
SEQUENCE_LENGTH = PLAN_DAYS * MEALS_PER_DAY

# 🔸 Columns representing the user’s numerical health data (must match model training)
NUMERICAL_COLS = [
    'Age', 'Weight (kg)', 'Height (cm)', 'BMI (auto-calculated)', 'Waist Circumference (cm)',
    'Fasting Blood Sugar (mg/dL)', 'HbA1c (%)', 'Postprandial Sugar (mg/dL)', 'LDL (mg/dL)',
    'HDL (mg/dL)', 'Triglycerides (mg/dL)', 'CRP (mg/L)', 'ESR (mm/hr)', 'Uric Acid (mg/dL)',
    'Creatinine (mg/dL)', 'Urea (mg/dL)', 'ALT (U/L)', 'AST (U/L)', 'Vitamin D3 (ng/mL)',
    'Vitamin B12 (pg/mL)', 'TSH (uIU/mL)'
]

# 🔸 Order of meals per day used for consistent plan structure
MEAL_ORDER = [
    'Early-Morning', 'Breakfast', 'Mid-Morning Snack', 'Lunch',
    'Afternoon Snack', 'Dinner', 'Bedtime'
]

# 🔸 Mapping meal slots to food categories to enforce structure
MEAL_CATEGORY_MAP = {
    'Early-Morning': ['Morning drink', 'Dry fruits and nuts'],
    'Breakfast': ['Breakfast dishes', 'Fruits'],
    'Mid-Morning Snack': ['Fruits', 'Smoothie', 'Dairy'],
    'Lunch': ['Indian breads', 'Dal', 'Sabzi', 'Rice dishes', 'One-pot meals'],
    'Afternoon Snack': ['Snacks', 'Beverage'],
    'Dinner': ['Indian breads', 'Dal', 'Sabzi', 'One-pot meals', 'Soups'],
    'Bedtime': ['Night time drinks'],
}

# ======================================================================================
# 🔹 Main function to generate training data from raw food and health data
# ======================================================================================
def create_training_data():
    print("📦 Loading data...")
    base_dir = os.path.dirname(os.path.abspath(__file__))
    health_path = os.path.join(base_dir, "data", "health_report.xlsx")
    food_path = os.path.join(base_dir, "data", "food_items.xlsx")

    health_df = pd.read_excel(health_path)
    raw_food_df = pd.read_excel(food_path)

    print("🔄 Pre-processing Food Data...")
    raw_food_df.columns = raw_food_df.columns.str.strip()
    # Fill NaN in crucial columns before aggregation
    for col in ['Meal_Type', 'Allergens', 'Category']:
        if col in raw_food_df.columns:
            raw_food_df[col] = raw_food_df[col].fillna('Unknown')

    agg_funcs = {col: 'first' for col in raw_food_df.columns if col not in ['Food_Item', 'Meal_Type', 'Allergens', 'Category']}
    agg_funcs['Meal_Type'] = lambda x: '/'.join(x.dropna().astype(str).unique())
    agg_funcs['Allergens'] = lambda x: '/'.join(x.dropna().astype(str).unique())
    agg_funcs['Category'] = lambda x: '/'.join(x.dropna().astype(str).unique())
    food_df = raw_food_df.groupby('Food_Item').agg(agg_funcs).reset_index()

    print(f"✅ Pre-processing complete. Processed {len(food_df)} unique food items.")

    if 'Food_Item' not in food_df.columns:
        raise ValueError("🛑 'Food_Item' column not found in food data.")

    food_list = sorted(food_df['Food_Item'].unique().tolist())
    food_vocab = {food: i + 3 for i, food in enumerate(food_list)}
    food_vocab['<pad>'] = 0
    food_vocab['<sos>'] = 1
    food_vocab['<eos>'] = 2

    saved_models_dir = os.path.join(base_dir, 'saved_models')
    os.makedirs(saved_models_dir, exist_ok=True)
    vocab_path = os.path.join(saved_models_dir, 'food_vocab.json')
    with open(vocab_path, 'w') as f:
        json.dump(food_vocab, f, indent=4)
    print(f"✅ Vocabulary saved to: {vocab_path} with {len(food_vocab)} tokens")

    # ======================================================================================
    # 🔹 Generate training plans for each user
    # ======================================================================================
    training_samples = []
    print(f"\n🚀 Generating {NUM_PLANS_PER_USER} structured plans for each of the {len(health_df)} users...\n")

    for _, user_row in tqdm(health_df.iterrows(), total=len(health_df), desc="Generating plans"):
        allowed_foods_df, _ = get_allowed_foods(user_row, food_df)

        if len(allowed_foods_df) < 20: # Increased threshold for variety
            tqdm.write(f"⚠️ Skipping user {user_row.get('Full Name', 'N/A')} (only {len(allowed_foods_df)} allowed foods)")
            continue

        # ⭐️ Build category-wise menu
        allowed_by_category = {}
        all_categories = set(cat.strip() for all_cats in food_df['Category'].unique() for cat in all_cats.split(','))
        for category in all_categories:
            cat_foods = allowed_foods_df[
                allowed_foods_df['Category'].str.contains(category, case=False, na=False)
            ]['Food_Item'].tolist()
            allowed_by_category[category] = cat_foods

        for _ in range(NUM_PLANS_PER_USER):
            plan_names = []
            for day_num in range(PLAN_DAYS):
                # ⭐️ New Template-based daily plan generation
                is_veg = user_row.get('Dietary Preference', 'Vegetarian').lower() == 'vegetarian'

                # --- Lunch Template ---
                lunch_choices = []
                if np.random.rand() < 0.3 and allowed_by_category.get('One-pot meals'): # 30% chance for one-pot
                    lunch_choices.append(np.random.choice(allowed_by_category['One-pot meals']))
                else: # 70% chance for Thali
                    if allowed_by_category.get('Indian breads'): lunch_choices.append(np.random.choice(allowed_by_category['Indian breads']))
                    if allowed_by_category.get('Dal'): lunch_choices.append(np.random.choice(allowed_by_category['Dal']))
                    if allowed_by_category.get('Sabzi'): lunch_choices.append(np.random.choice(allowed_by_category['Sabzi']))

                # --- Dinner Template ---
                dinner_choices = []
                if np.random.rand() < 0.4 and allowed_by_category.get('One-pot meals'):
                    dinner_choices.append(np.random.choice(allowed_by_category['One-pot meals']))
                else:
                    if allowed_by_category.get('Indian breads'): dinner_choices.append(np.random.choice(allowed_by_category['Indian breads']))
                    if is_veg and allowed_by_category.get('Sabzi'): dinner_choices.append(np.random.choice(allowed_by_category['Sabzi']))
                    if not is_veg and allowed_by_category.get('Non-veg curry'): dinner_choices.append(np.random.choice(allowed_by_category['Non-veg curry']))
                    else: # Fallback for non-veg if no curry available
                        if allowed_by_category.get('Dal'): dinner_choices.append(np.random.choice(allowed_by_category['Dal']))

                # --- Assemble day plan by picking one representative item per slot ---
                daily_meal_map = {
                    'Lunch': lunch_choices,
                    'Dinner': dinner_choices,
                }

                for meal_slot in MEAL_ORDER:
                    choices = []
                    if meal_slot in daily_meal_map and daily_meal_map[meal_slot]:
                        choices = daily_meal_map[meal_slot]
                    else: # For non-template meals
                        for category in MEAL_CATEGORY_MAP.get(meal_slot, []):
                            choices.extend(allowed_by_category.get(category, []))

                    if not choices: # Fallback to any allowed food
                        choices = allowed_foods_df['Food_Item'].tolist()
                    
                    if not choices: continue

                    # We still only append ONE food per slot to keep the sequence length fixed for the model
                    plan_names.append(np.random.choice(choices))


            if len(plan_names) != SEQUENCE_LENGTH:
                continue

            plan_ids = [food_vocab[food] for food in plan_names]
            user_vector = user_row[NUMERICAL_COLS].fillna(0).values.astype(float)

            training_samples.append({
                'user_vector': list(user_vector),
                'plan_sequence': plan_ids
            })

    # ======================================================================================
    # 🔹 Save final dataset to disk
    # ======================================================================================
    training_df = pd.DataFrame(training_samples)
    training_df['user_vector'] = training_df['user_vector'].apply(json.dumps)
    training_df['plan_sequence'] = training_df['plan_sequence'].apply(json.dumps)
    data_dir = os.path.join(base_dir, 'data')
    os.makedirs(data_dir, exist_ok=True)
    training_path = os.path.join(data_dir, '1_bootstrap_training_data.csv')
    training_df.to_csv(training_path, index=False)
    print(f"\n✅ All Done! Saved {len(training_df)} high-quality training samples to: {training_path}")

if __name__ == '__main__':
    create_training_data()